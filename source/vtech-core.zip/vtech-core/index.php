<?php
// Silence is golden.
// Silence is life.

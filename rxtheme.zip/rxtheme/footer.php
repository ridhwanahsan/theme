<?php

get_template_part('template-parts/footer/footer-1');
wp_footer(); ?>

</body>

</html>